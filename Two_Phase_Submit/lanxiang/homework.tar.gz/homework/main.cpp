#include "server.h"
#include <iostream>
using namespace std;
using namespace homework;

int main()
{
    return 0;
}
